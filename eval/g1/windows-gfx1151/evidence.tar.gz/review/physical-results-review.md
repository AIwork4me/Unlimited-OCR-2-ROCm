# Independent physical-result and CPU-analysis review

Decision: PASS for the captured original-wheel Windows gfx1151 comparison and
the explicitly scoped failure-contract evidence. The final committed analyzer
and fresh CPU replay binding now verify; the publication provenance follow-up
is CLOSED. No physical rerun is required by this review. Run-02 remains intact.

This reviewer ran only CPU tests and read-only artifact/hash checks. No real
torch import, model inference, GPU command, source edit or physical-artifact
mutation was performed. Review code/output lives in this review directory.

## What the physical evidence establishes

- Both supervised arm processes exited 0 at recorded producer commit
  `a68e88a658ab6a6958c05c15d6ddf9caf66e9cb3`. Their run receipts bind the exact
  reviewed harness SHA256
  `5983da029cb62ee19d3221d7c9c2700931212fee6c2895b2f33c36e60b027e51`.
  Supervisor source and stdout/stderr/host-stream hash seals verify.
- All 13 normal cases in each arm pass the unchanged fixture ground-truth
  gate. Corresponding native UTF-8 bytes, output IDs, prompt IDs, finish/page
  fields and prompt text match exactly: **4,484 bytes per arm**. The per-step
  guard traces, guard counts, 12 BF16 cuda:0 synchronized DASH kernel events,
  vision scope events and loaded official model source identities also match.
- Seven multipage wrapper results change from
  `upstream_tuple_no_finish_field` to authoritative native `stop`. Their native
  results were already `stop` in both arms. No native `length` was relabelled
  as `stop`; the change preserves information discarded by the old tuple caller.
- The two-page text runs and two-page table contain three PAGE markers because
  the last is empty. Both callers retain identical raw bytes. Their terminal
  guard branch is `force_eos_excess_pages`; the remaining normal cases finish
  on `unmodified`. This is not proof of unconstrained natural EOS or semantic
  completeness outside the scored synthetic fixtures.
- Both eight-token wrapper-length failures remain FAIL with native `length`
  and eight returned IDs. Both lowered-context controls return native `length`
  at eight IDs despite requested max_new_tokens 64. Both lowered-page-cap
  controls remain DIAGNOSTIC_ONLY, show actual official forced-page/EOS branches
  and fail semantic acceptance. They are not ordinary accepted OCR cases.
- The after-arm controlled interrupt records three completed real decoder
  forwards, two guard steps, explicit INTERRUPTED failure, restored runtime
  state and no native dictionary/raw return. The subsequent retry matches its
  normal two-page reference exactly. It does not fabricate partial text or IDs.
- All **34** physical case summaries (16 before, 18 after) have clean recorded
  HIP probes, restored runtime state and PASS physical contracts, with no
  telemetry_error. Expected inference failures stay visible as failures.

The preflight identity binds the original AMD wheel SHA256
`415d2dbd4b6ab002cff1c54795fdd66322abd9a46bf982cb64eebb4493ac2e7c`.
All 15 loaded torch DLL/PYD hashes match its original native members after load
and after suite in each arm, and in the additional MATH control. Loaded model
source hashes agree with the verified pinned snapshot and both arms' source/
weight hashes match preflight. No model, wheel, algorithm or cap change is
indicated by these receipts.

## Actual MATH operator control

Read-only audit of `.b/g1-physical/profile_math.py` found normal model loading,
the unchanged current wrapper, the passive native observer and CPU profiler
instrumentation; no tensor/logit edits or algorithm substitutions occur.

The extra one-page physical control records 72
`aten::_scaled_dot_product_attention_math` operations and no flash/efficient
SDPA operation. CPU profiler activity records operator dispatch names; it is
not evidence of CPU compute fallback. The model/vision evidence retains GPU
device identity. Its raw English bytes, output IDs, prompt IDs and native finish
match the after-arm English capture. HIP before and after both have peek 0;
runtime and driver APIs both return success and version 71460850. No speed or
per-case operator-profile claim is made for the unprofiled normal arm sequence.

Private profiler source SHA256:
`4a81bc733618379477946ef45086694bbe53e785dfa66ecbeb8302120df0bd95`.
Dispatch receipt SHA256:
`4124b36a431767713de2ddc4950fba1bf814dbfeacf0783ac00014081c9181dc`.

## CPU ledger replay and analyzer

Reviewed analyzer SHA256:
`c9b15a44b6555d45365906b4a19aa5bc96f9e90ec34146f9e6d1df4d5f59d899`.
Reviewed analysis-test SHA256:
`94752edaa6d74a83b6317c6f141c6dc0bce456d1843c1817f97997594ec2aa48`.

The analyzer reads captured evidence and compares identities and exact output;
it executes no native inference. `source_identity` excludes only per-process
cache paths while retaining source hashes/function/line. Failed/missing normal
or physical control evidence cannot produce an overall PASS. The arm gate
validates suite statuses, arm identities, harness equality and artifact seals.

The replay invokes the real production append-only Run ledger on captured or
clearly labelled authored/derivative text. It is explicitly **CPU replay, not
new GPU corruption or interruption evidence**. Original IDs are retained as
capture provenance and explicitly not claimed to generate derivative text.
The seven documents/fourteen pages retain eight attempts and the full latest-
document outcomes: PASS 2, FAIL 3, TRUNCATED 1, NOT_RUN 1, OOM/TIMEOUT 0.
The interrupted pending attempt and later retry remain separate. Injected
rename failure leaves the preceding committed raw/COMMIT unchanged and preserves
the new pending raw/COMMIT. All seven COMMIT seals, including that pending seal,
verify. OOM and timeout are explicitly NOTRUN in physical and replay evidence.

Focused CPU verification: **36 passed in 1.09s**, comprising harness tests,
analysis tests and seven independent reviewer probes. Raw output:
`physical-analysis-pytest.log`; no real torch/GPU execution occurred in tests.
The repository-root command was:

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
& '.b/benchmark-cpu/Scripts/python.exe' -m pytest tests/unit/test_native_regression.py tests/unit/test_native_regression_analysis.py '.b/g1-physical/review/test_review_probes.py' --basetemp '.b/g1-physical/review/physical-analysis-pytest' -o 'cache_dir=.b/g1-physical/review/physical-analysis-pytest-cache' -q
```

## Memory and resource-append limits

All 26 normal-case resource fact source hashes, prompt/output ID hashes, token
counts and before/after memory snapshots match their physical summaries. The
document's measured table uses bytes/2^30 with three-decimal rounding. Before
and after have the same largest recorded GPU allocated/reserved peaks:
9,222,452,224 / 11,284,774,912 bytes. Largest recorded process-lifetime peak
working sets are 11,997,757,440 before and 11,945,385,984 after.

These are actual in-worker snapshots and allocator peaks. The parent host stream
sampled the roughly 4-MB venv launcher, not the model worker; it cannot establish
continuous worker RSS peaks, watchdog coverage or cleanup. Process-lifetime peak
RSS is not a per-request peak. GPU reservations can persist across cases; APU
allocation is not dedicated VRAM or total system usage. The append states all
these limits, and that five-page output used only 286 IDs rather than exercising
the 5,120 requested ceiling. It grants no higher-tier admission.

The append mapping's before/after/facts hashes verify. Bytes before and after
the measurement replacement are unchanged, including the independently reviewed
policy, historical evidence and future-tier restrictions. No broader policy
re-audit or higher-tier validation is implied.

## New findings / publication follow-up

1. The private profiler script's PASS branch checks operator count/output parity
   but does not itself reject nonzero HIP probe results. This is a prospective
   diagnostic-tool gate gap; **current evidence is unaffected**, because this
   review separately verified both actual HIP probes and API return values.
   Preserve the historical producer; require clean probes if reusing its status.
2. CLOSED: Run-02 lacked an analyzer SHA/producer commit/argv receipt. A fresh
   final analysis and real ledger replay now bind committed producer
   `26e9abef58164b9bc6b997d4699b63d5fa2b8f98` and unchanged analyzer SHA
   `c9b15a44b6555d45365906b4a19aa5bc96f9e90ec34146f9e6d1df4d5f59d899`.
   Read-only `git show <commit>:experiments/native_regression/analyze.py`
   bytes hash to that exact SHA and match current source. The producer receipt
   records exact argv and exit 0, binds stdout/stderr and output-manifest hashes;
   stderr is empty. Final analysis is identical to reviewed run-02. The fresh
   final replay's 58 manifest entries and seven ledger COMMIT seals verify,
   with the same seven-document/fourteen-page/eight-attempt contracts. Neither
   physical artifacts nor run-02 was replaced.

No unresolved result-correctness P1/P2 issue was found in the captured comparison.
Scope remains the original published stack on this physical Windows gfx1151
device and these synthetic 1/2/3/5-page cases. No 15/30/50/100-page, full-dataset,
new-hardware, performance, OOM, timeout or release/merge claim follows.

## Independent seal anchors

`physical-artifact-checks.json` and `.log` contain the stdlib review result PASS,
with no errors: 719 recorded hash entries across 39 manifests, plus supervisor
logs, ledger COMMIT seals, provider/source comparisons and resource fact checks.
Root hash-manifest SHA256 values:

| Evidence | Root hashes.json SHA256 |
|---|---|
| before | 47a327a2f120b57284f8675867dcc7ddb6a9801c21e703323d36a19c896fa8fb |
| after | a7d0f32b4b69469d4fa70bac8371b6f8ef805bc082001cfcb23c60e34ae63f94 |
| comparison | f7735f22205893605f4c6b8c40ddd7acf017dfb6f1504f0e473e2343ad153e19 |
| analysis/run-02 | 19e3316d200563afbc0ddfd737ab3cd581c974cf44bd294e901afc42d16b308d |
| failure-replay-02 | 190f2068bd9e885f8538134bc717baafdac2b515fcd636daa8d03bce1c23a539 |
| analysis/final | 56bf619b9f9953b4beba998a2d8d3aac454ff195c68f7cf3f2ca01b13331e99f |
| failure-replay-final | 8d3a3cfeb7d14d21789a7ba310f6f5c4c52f2bfc963bdb06fc2780dd7d88b65d |

Final binding details and exact argv are in
`final-producer-binding-review.json` / `.log`, status PASS with no errors.
The final producer-receipt.json SHA256 is
`13ea283bf4f67b4f19b3900f628f8f9dad29d1ca170e22c044463ec3e8639831`.
