# Independent before-GPU harness review

Decision: APPROVED FOR PARENT-CONTROLLED PHYSICAL RUN at the exact hashes below.
No unresolved P1/P2 findings remain in the reviewed harness. This is CPU/static
review approval, not a GPU result or G1 acceptance.

Reviewed from the primary repository root on 2026-10-29. The reviewer did not
load real torch, execute a model, a GPU command, an arm, or any Git operation; no production
source was edited. Additional probes and review evidence are under this directory.

## Final reviewed hashes (SHA256)

| File | SHA256 |
|---|---|
| experiments/native_regression/runner.py | 5983da029cb62ee19d3221d7c9c2700931212fee6c2895b2f33c36e60b027e51 |
| tests/unit/test_native_regression.py | 1fccac63497cafb3cecf7e5363e627ab60b22a483e5d211135f86537edaf8c2f |
| .b/g1-physical/harness-plan.md | eb9bb7f0c1a1b89935d74c91925f56ff3629b6ca165b59787f46c6ffd14c1b10 |
| .b/g1/before-inference.py | 1a815fd4886eda5628801d51fcc3d150fb8a2ede44ec980be60863cb24e9a85c |
| .b/g1/baseline-source-hashes.json | ada48a3047d63ac260070a6e0e3c8aa6ff579dce83d06306d1d01f306b82bbcc |
| src/unlimited_ocr_2_rocm/inference.py | 6e8a732c14f12dedf0c0a31d151b80dbef196fd686ff9194b0b2720af5ee1564 |
| src/unlimited_ocr_2_rocm/completion.py | 7ea47e656f1dfb5ceb34a1bfa64942838a992cbd12122d87359a5aeaae72f873 |
| src/unlimited_ocr_2_rocm/model.py | 885403a2c678d99347dae31ea74e046ddd6b58dc81ca4d2d1c7d826a11dc2ca4 |
| src/unlimited_ocr_2_rocm/compat.py | 57144ea391f327fae43645601bc9a635b108cc69de8f9b1d04e37d7cbfe99432 |
| tests/fixtures/ground_truth.json | aeb3c76c2fb401b1e3dc609f2346d11515569e27ce0d5adc4ee21ea36f06e47f |

The helper baseline proof rejects changes in model/output/compat/config/doctor
against the extracted receipt and also requires byte equality with current helpers.
The historical inference snapshot is checked against that receipt before import.
Commit provenance of the extracted receipt is the parent's preceding extraction
evidence; this independent reviewer performed no Git operations.

## Findings resolved before approval

- P1: normal-only comparison could return success after a failed interruption,
  retry, or requested control suite, or with the wrong arm directories. The final
  comparison requires before/after run identities, both suite PASS statuses,
  matching harness hashes, and each recorded artifact hash.
- P1: a final synchronization/memory exception could be recorded as FAIL while
  physical_contract remained PASS; expected length/interruption failures already
  require FAIL, so the exception could hide inside expected failure acceptance.
  The final physical gate and both expected-failure gates exclude telemetry_error.
  A focused regression test reproduces the former length false-PASS path.
- P2: requested controls initially did not affect the suite result. They now have
  separate max-length and page-cap diagnostic contracts and cannot count as
  ordinary accepted fixture cases. Missing controls fail when requested.
- P2: missing physical evidence/restoration could survive comparison or the length
  gate. Final normal, length, interruption and retry paths require the relevant
  physical/restoration contracts; empty kernel evidence fails comparison.
- P2: final JSON/raw/hash artifacts were initially streamed directly to final
  names. Complete serialized bytes now publish atomically by same-directory
  hardlink, refuse overwrite, and leave no partial final JSON on serialization
  failure. guard.jsonl remains explicitly incremental interruption evidence.
- P2: initial reset/synchronize/memory telemetry occurred outside the protected
  case boundary. The final ordering samples HIP first and runs initial telemetry
  inside the case try; a dedicated CPU boundary test confirms an initial sync
  exception retains an explicit failed summary with physical_contract FAIL.

## Static fidelity checks

Read the pinned official modeling_unlimitedocr.py infer, infer_multi,
_uocr_generate and _uocr_page_count_guard definitions, and the pinned
modeling_deepseekv2.py configure_dash_inference implementation from revision
9cf077c4b206e0e2a31879df937b0b0bcba3661c without importing them.

- The infer observer calls the original once and returns that same object. It
  freezes the returned dictionary before the historical infer_multi discards
  dictionary metadata in its tuple return. No text, token, tensor or logits edit
  occurs. Official guard invocation and returned object are preserved; branch
  classification matches the exact post-state conditions in the pinned guard.
- Actual historical run_native remains the before caller. The current caller's
  multi-page infer options match official infer_multi's base-mode delegation;
  single-page auto-crop defaults remain native defaults. Normal cases do not
  broaden max_length/max_page_tokens or disable the page guard/DASH/SR-SWA.
- Thirteen normal cases retain the exact 1/2/3/5-page fixture coverage including
  math, per-page budgets, Unicode recovery, repeated multipage runs and tables.
  Length/context/page-cap cases retain their separate diagnostic classifications.
- The fault injection calls the real decoder forward first, synchronizes its
  third completed call, then raises the disclosed KeyboardInterrupt once. The
  patched callable is restored in finally. Official generation finally restores
  the configured runtime knobs; the harness observes their before/after values
  and requires a matching physical retry. No native return is fabricated when
  the official loop raises before returning.
- HIP inspection uses an already-loaded runtime handle and peek (no error clear),
  preserves nonzero errors, and records version API results. Loaded native image
  and imported model source hashes are preserved for parent identity review.

Vision evidence identifies unchanged scoped MATH selection source and its
successful forward events. It does not claim independently observed aten MATH
operator dispatch. The parent explicitly accepted that scope for this comparison.
Original published wheel/native-member identity rests on the prior physical
preflight plus the new arm snapshots; it is not proved by CPU tests here.

## CPU verification

The final runner/test hashes were sampled before and after verification, compared
for equality, and match the table. Machine-readable copy:
final-reviewed-source-hashes.json.
Command (PowerShell, repository-root cwd):

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
& '.b/benchmark-cpu/Scripts/python.exe' -m pytest tests/unit/test_native_regression.py '.b/g1-physical/review/test_review_probes.py' --basetemp '.b/g1-physical/review/harness-pytest-final-rebound' -o 'cache_dir=.b/g1-physical/review/pytest-cache-final-rebound' -q
```

Result: **32 passed in 0.30s** (25 repository tests plus 7 independent probes).
Raw final output: pytest-final-rebound.log. Independent probes cover restoration on
native/synchronize exceptions, no fabricated native interrupted return, exact
effective default capture, failure gates, required controls and artifact tampering.
No physical validation is represented by these synthetic CPU unit tests.

Parent execution must retain the original frozen environment and process-scoped
TMP/TEMP/download/build caches within the repository. Physical acceptance still
requires both complete arm suites and the final comparison to pass, followed by
review of raw native/guard/kernel/source/identity evidence.
