# Independent G1 resource-strategy review

Date: 2026-10-29. Scope: source/resource design only. No torch, tokenizer or remote-model imports, GPU work, downloads, implementation edits or Git operations. Commands ran from the primary repository root. AGENTS.md was read.

Disposition: PASS for this source-derived strategy. P1 findings: 0. P2 findings: 0. Source arithmetic and retention of current caps PASS. New physical measurements remain PENDING; higher tiers remain BLOCKED. Final narrow-document re-review completed without GPU/model imports or implementation changes.

## Final review and resolved findings

No remaining P1/P2 issues in the reviewed final strategy.

- User cancellation now records `FAIL` with `CANCELLED`/`INTERRUPTED`, preserves the attempted run, stops progression, terminates and awaits only the owned tree with PID identity checks, and retains cleanup failures. Fresh authorized retries preserve prior failures and rerun identity/health checks. The existing monitoring/cleanup prerequisite blocks higher tiers when reliable cleanup is absent. These are future-worker requirements, not claims of an implemented supervisor.
- Full benchmark blockers now use the actual document counts and ranges: MPDocBench 420 documents / 3135 pages / range 2–30 / 249 above five; MarathonDocBench 100 documents / 18272 pages / range 103–298 / all above the proposed 100-page probe. The frozen-manifest counts were independently computed. `274*298+32=81684` and `131072-81684=49388` are correct and explicitly labelled context arithmetic, not sufficient output capacity or measured admission. No hypothetical 420-page case is asserted.
- The draft explicitly preserves the existing semantic environment gate, frozen routing identity and caps. The prospective Python path uses the original retained environment rather than the candidate build environment; TEMP/TMP share the short compatibility path and the command working directory remains the repository root. No environment or physical commands were executed by this reviewer.

The initially reviewed document hash was `5575134c72883f546f4764d1c29804da07fbd7ea68dc098a9b416fbec9899a2b`; the final reviewed hash below supersedes that draft for this disposition.
Manifest identities independently inspected with stdlib JSON: `eval/benchmarks/manifests/MPDocBench.jsonl` SHA-256 `785f18884dc586aa836f096dcba7c96c1fd0cc50a6dae9f62aabb0152d4bdcc8`; `eval/benchmarks/manifests/MarathonDocBench.jsonl` SHA-256 `2515b579828e787c6cc928421abd6c693086d64084ba26a459f82ccf21a9fe76`. Counts refer to documents, not a hypothetical 420-page request.

## Verified conclusions

- Source threat assumption checked: pinned decoder permits `DASH_STAGE0` to override checkpoint routing, but current `model.py:41–55` already rejects conflicting/unknown semantic environment controls before load, with repeated checks in observed kernels and CPU coverage in `test_native_versions.py`. Preserve this guard in the future worker and freeze effective routing identity. This is not a missing current guard or a request to implement a new one.
- Independently streamed SHA-256 for all 16 locked source/config/tokenizer/index files and both weight shards: all 18 match `upstream-lock.json`. Read the pinned implementation as text and tokenizer/config JSON only.
- Base page: `ceil((1024/16)/4)=16`; image IDs `16*(16+1)+1=273`. Locked tokenizer JSON includes `<PAGE>` ID 128827; default base prompt reserves one PAGE per image plus BOS/instruction overhead. `274*n+32` is correctly labelled an allowance requiring actual-ID confirmation, not an exact tokenizer guarantee. Single auto-crop can add tokens and needs separate identity.
- Independent arithmetic for all five 5/15/30/50/100 rows matches JSON: 61440 BF16 K/V bytes plus 6144 FP32 router bytes = 67584 bytes = 66 KiB/cached token. 100-page envelope 125736 leaves 5336 context positions. One-layer FP32-copy and one prefill-score formulas are correct as selected payloads, not peak bounds.
- Current source still enforces five images, 8192 requested new tokens and 16000000 pixels/page; native context/page caps remain 131072/20000. The draft accurately notes some current validation occurs after load. The separate resource-policy PR must move all admission checks before GPU load and keep normal-profile rejection.
- Official source temporarily clears ring/sliding-window values and restores them in its `finally`; no patch is proposed. Full DynamicCache K/V and FP32 router concatenation remain length-dependent. Source setup before that `try` can still fail; fresh-process failure isolation remains necessary. No constant-cache/SGLang-parity claim is supported.
- GPU allocated/reserved/RSS are correctly separated for the APU. The analytic margin formula and sampled abort budgets cannot enforce a hard GPU ceiling, and the draft explicitly says so. Absence of live telemetry/confirmed cleanup must continue to block higher tiers. Neither model tensor payload nor context capacity certifies fit.
- Historical 15-page evidence is accurately identified as a separate unscored diagnostic with 39321 ceiling, not new G1 acceptance or wrapper support. New 1/2/3/5 measurements remain PENDING. Source-derived policy must receive a new review if changed after this review; appending measured receipts does not retroactively validate higher tiers.

## Reviewed byte identities

SHA-256:

- `docs/G1_LONG_DOCUMENT_RESOURCE_STRATEGY.md`: `b41932336b2a4211e66233d1e0f8233a29bf581cb60ad2f2a6dd70eccab92b33`
- `.b/g1-physical/resource/calculate_resource_envelope.py`: `39e4d5c4b5e349fd3ed85a1c2800019462ecbeda6b570b873fa489ef17140b6d`
- `.b/g1-physical/resource/analytical-envelope.json`: `467c9621d198ed9b9c199ef100059478890c6435daef102c1c2c31956b82f01c`
- `.b/g1-physical/resource/source-hash-facts.json`: `09ea43fe37fc67efa335eae2ead3538f15d4119fd644f65fa697244474836611`
- `src/unlimited_ocr_2_rocm/upstream-lock.json`: `ffd730234a34504a78f5df5eb025d8341695abd51ce9025caaddeebf45e687de`

The source-hash receipt enumerates the 18 reviewed model files; this reviewer independently rehashed their current bytes. This receipt does not assert new physical results.
